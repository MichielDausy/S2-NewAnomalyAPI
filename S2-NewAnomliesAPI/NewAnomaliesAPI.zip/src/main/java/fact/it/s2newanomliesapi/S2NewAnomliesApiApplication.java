package fact.it.s2newanomliesapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S2NewAnomliesApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(S2NewAnomliesApiApplication.class, args);
    }

}
