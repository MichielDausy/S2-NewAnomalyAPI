package fact.it.s2newanomliesapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S2NewAnomliesApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
